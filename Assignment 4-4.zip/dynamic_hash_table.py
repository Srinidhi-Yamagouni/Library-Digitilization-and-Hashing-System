from hash_table import HashSet, HashMap
from prime_generator import get_next_size

class DynamicHashSet(HashSet):
    def __init__(self, collision_type, params):
        super().__init__(collision_type, params)

    def insert(self, x):
        super().insert(x)
        if self.get_load() >= 0.5:
            self.rehash()

    def rehash(self):
        old_table = self.hash_table
        old_size = self.size
        
        new_size = get_next_size()
        new_params = list(self.params)
        new_params[-1] = new_size
        
        self.__init__(self.collision_type, new_params)
        
        if self.collision_type == "Chain":
            for chain in old_table:
                for item in chain:
                    if item:
                        self.insert(item)
        else:
            for i in range(old_size):
                if old_table[i] is not None:
                    self.insert(old_table[i])

class DynamicHashMap(HashMap):
    def __init__(self, collision_type, params):
        super().__init__(collision_type, params)

    def insert(self, x):
        super().insert(x)
        if self.get_load() >= 0.5:
            self.rehash()

    def rehash(self):
        old_table = self.hash_table
        old_size = self.size
        
        new_size = get_next_size()
        new_params = list(self.params)
        new_params[-1] = new_size
        
        self.__init__(self.collision_type, new_params)
        
        if self.collision_type == "Chain":
            for chain in old_table:
                for item in chain:
                    if item:
                        self.insert(item)
        else:
            for i in range(old_size):
                if old_table[i] is not None:
                    self.insert(old_table[i])