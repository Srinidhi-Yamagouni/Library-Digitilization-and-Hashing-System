from prime_generator import get_next_size

class HashTable:
    def __init__(self, collision_type, params):
        self.collision_type = collision_type
        self.size = params[-1]
        self.params = params
        self.hash_table = [None] * self.size
        self.count = 0

        if self.collision_type == "Chain":
            self.z = params[0]
            self.hash_table = [[] for _ in range(self.size)]
        elif self.collision_type == "Double":
            self.z1 = params[0]
            self.z2 = params[1]
            self.c2 = params[2]
        else:
            self.z = params[0]

    def hash_func(self, key, z):
        power_z = 1
        sum = 0
        for char in key:
            p = ord(char) - (ord('a') if char.islower() else ord('A') - 26)
            sum += power_z * p
            power_z *= z
        return sum
    
    def get_slot(self, key):
        if self.collision_type == "Double":
            return self.hash_func(key, self.z1) % self.size
        return self.hash_func(key, self.z) % self.size

    def get_slot_1(self, key):
        if self.collision_type == "Double":
            h1 = self.hash_func(key, self.z1) % self.size
            h2 = self.c2 - self.hash_func(key, self.z2) % self.c2
            i, slot = 0, h1
            while self.hash_table[slot] is not None and (isinstance(self.hash_table[slot], tuple) and self.hash_table[slot][0] != key or not isinstance(self.hash_table[slot], tuple) and self.hash_table[slot] != key):
                if i >= self.size:
                    return None
                i += 1
                slot = (h1 + i * h2) % self.size
            return slot
        elif self.collision_type == "Linear":
            h1 = self.hash_func(key, self.z) % self.size
            i, slot = 0, h1
            while self.hash_table[slot] is not None and (isinstance(self.hash_table[slot], tuple) and self.hash_table[slot][0] != key or not isinstance(self.hash_table[slot], tuple) and self.hash_table[slot] != key):
                if i >= self.size:
                    return None
                i += 1
                slot = (h1 + i) % self.size
            return slot
        else:
            return self.hash_func(key, self.z) % self.size

    def get_load(self):
        return self.count / self.size

class HashSet(HashTable):
    def __init__(self, collision_type, params):
        super().__init__(collision_type, params)

    def insert(self, key):
        if self.collision_type == "Chain":
            slot = self.hash_func(key, self.z) % self.size
            if key not in self.hash_table[slot]:
                self.hash_table[slot].append(key)
                self.count += 1
        else:
            slot = self.get_slot_1(key)
            if slot is None:
                raise Exception("Table is full")
            if self.hash_table[slot] is None:
                self.hash_table[slot] = key
                self.count += 1

    def find(self, key):
        h1 = self.hash_func(key, self.z1 if self.collision_type == "Double" else self.z) % self.size
        if self.collision_type == "Chain":
            return key in self.hash_table[h1]
        elif self.collision_type == "Linear":
            i, slot = 0, h1
            while self.hash_table[slot] != key:
                if i >= self.size or self.hash_table[slot] is None:
                    return False
                i += 1
                slot = (h1 + i) % self.size
            return True
        else:
            h2 = self.c2 - self.hash_func(key, self.z2) % self.c2
            i, slot = 0, h1
            while self.hash_table[slot] != key:
                if i >= self.size or self.hash_table[slot] is None:
                    return False
                i += 1
                slot = (h1 + i * h2) % self.size
            return True

    def __str__(self):
        res = []
        for slot in self.hash_table:
            if slot is None:
                res.append("<EMPTY>")
            elif self.collision_type == "Chain" and slot:
                res.append(" ; ".join(slot))
            else:
                res.append(slot if slot else "<EMPTY>")
        return " | ".join(res)

class HashMap(HashTable):
    def __init__(self, collision_type, params):
        super().__init__(collision_type, params)

    def insert(self, x):
        if self.collision_type == "Chain":
            slot = self.hash_func(x[0], self.z) % self.size
            for i, (k, v) in enumerate(self.hash_table[slot]):
                if k == x[0]:
                    self.hash_table[slot][i] = x
                    return
            self.hash_table[slot].append(x)
            self.count += 1
        else:
            slot = self.get_slot_1(x[0])
            if slot is None:
                raise Exception("Table is full")
            if self.hash_table[slot] is None or self.hash_table[slot][0] != x[0]:
                self.count += 1
            self.hash_table[slot] = x

    def find(self, key):
        h1 = self.hash_func(key, self.z1 if self.collision_type == "Double" else self.z) % self.size
        if self.collision_type == "Chain":
            for k, v in self.hash_table[h1]:
                if k == key:
                    return v
            return None
        elif self.collision_type == "Linear":
            i, slot = 0, h1
            while self.hash_table[slot] is not None:
                if self.hash_table[slot][0] == key:
                    return self.hash_table[slot][1]
                i += 1
                slot = (h1 + i) % self.size
                if slot == h1:
                    break
            return None
        else:
            h2 = self.c2 - self.hash_func(key, self.z2) % self.c2
            i, slot = 0, h1
            initial_slot = slot
            while self.hash_table[slot] is not None:
                if self.hash_table[slot][0] == key:
                    return self.hash_table[slot][1]
                i += 1
                slot = (h1 + i * h2) % self.size
                if slot == initial_slot:
                    break
            return None

    def __str__(self):
        res = []
        for slot in self.hash_table:
            if slot is None:
                res.append("<EMPTY>")
            elif self.collision_type == "Chain" and slot:
                res.append(" ; ".join(f"({k}, {v})" for k, v in slot))
            else:
                res.append(f"({slot[0]}, {slot[1]})" if slot else "<EMPTY>")
        return " | ".join(res)