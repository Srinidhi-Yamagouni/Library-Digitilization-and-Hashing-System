import hash_table as ht

class DigitalLibrary:
    def __init__(self):
        pass
    
    def distinct_words(self, book_title):
        pass
    
    def count_distinct_words(self, book_title):
        pass
    
    def search_keyword(self, keyword):
        pass
    
    def print_books(self):
        pass

def merge(S1, S2):
    result = []
    i = j = 0
    
    while i < len(S1) and j < len(S2):
        if i > 0 and (S1[i]) ==(S1[i - 1]):
            i += 1
            continue
        if j > 0 and (S2[j]) == (S2[j - 1]):
            j += 1
            continue

        if (S1[i]) <(S2[j]):
            result.append(S1[i])
            i += 1
        elif (S1[i]) > (S2[j]):
            result.append(S2[j])
            j += 1
        else:
            result.append(S1[i])
            i += 1
            j += 1

    while i < len(S1):
        if not result or (result[-1]) != (S1[i]):
            result.append(S1[i])
        i += 1
    
    while j < len(S2):
        if not result or (result[-1]) != (S2[j]):
            result.append(S2[j])
        j += 1
    
    return result

def merge_sort(S):
    n = len(S)
    if n < 2:
        return S
        
    mid = n // 2
    S1 = S[:mid][:]
    S2 = S[mid:][:]
    
    S1 = merge_sort(S1)
    S2 = merge_sort(S2)
    
    return merge(S1, S2)

class MuskLibrary(DigitalLibrary):
    def __init__(self, book_titles, texts):
        self.book_titles=book_titles[:]
        self.texts=texts[:]
        for i in range(len(self.texts)):
            self.texts[i]=merge_sort(self.texts[i])
        self.books_texts_pairs=list(zip(self.book_titles, self.texts))
        self.books_texts_pairs=merge_sort(self.books_texts_pairs)    

    def distinct_words(self, book_title):
        low=0
        high=len(self.books_texts_pairs)-1
        while low<=high:
            mid=(low+high)//2
            if self.books_texts_pairs[mid][0]== book_title:
                return self.books_texts_pairs[mid][1]
            elif self.books_texts_pairs[mid][0]< book_title:
                low=mid+1
            else:
                high=mid-1  
        return []  
    
    def count_distinct_words(self, book_title):
        dist_words=self.distinct_words(book_title)
        return len(dist_words)
    
    def search_keyword(self, keyword):
        res=[]
        def binary_search(keyword, text):
            low=0
            high=len(text)-1
            while low<=high:
                mid=(low+high)//2
                if text[mid]==keyword:
                    return True
                elif text[mid]<keyword:
                    low=mid+1
                else:
                    high=mid-1    
            return -1
        for title, text in self.books_texts_pairs:
            if binary_search(keyword, text)!=-1:
                res.append(title)
        return res               
    
    def print_books(self):
        for title, text in self.books_texts_pairs:
            print(f"{title}: { ' | '.join(text)}")

class JGBLibrary(DigitalLibrary):
    def __init__(self, name, params):
        self.name=name
        self.parameters=params
        if self.name == "Jobs":
            self.table=ht.HashMap("Chain", self.parameters)
        elif self.name == "Gates":
            self.table=ht.HashMap("Linear", self.parameters)
        else:
            self.table=ht.HashMap("Double", self.parameters)        

    def add_book(self, book_title, text):
        if self.name == "Jobs":
            texts=ht.HashSet("Chain", self.parameters)
        elif self.name == "Gates":
            texts=ht.HashSet("Linear", self.parameters)
        else:
            texts=ht.HashSet("Double", self.parameters)
        for tex in text:
            texts.insert(tex)
        self.table.insert((book_title, texts))
    
    def distinct_words(self, book_title):
        hash_set = self.table.find(book_title)
        if not hash_set:
            return []
            
        result = []
        for bucket in hash_set.hash_table:
            if bucket:
                if isinstance(bucket, list):
                    for el in bucket:
                        result.append(el)
                else:
                    result.append(bucket)
        
        return result
                
    def count_distinct_words(self, book_title):
        if self.table.find(book_title) is None:
            return 0
        return self.table.find(book_title).count
    
    def search_keyword(self, keyword):
        result = []
        for bucket in self.table.hash_table:
            if bucket:
                if isinstance(bucket, list):
                    for book_entry in bucket:
                        if book_entry and isinstance(book_entry, tuple):
                            book_title, word_set = book_entry
                            if word_set.find(keyword):
                                result.append(book_title)
                elif isinstance(bucket, tuple):
                    book_title, word_set = bucket
                    if word_set.find(keyword):
                        result.append(book_title)
        
        return result
    
    def print_books(self):
        if self.name == "Jobs":
            for i in range(self.table.size):
                slot = self.table.hash_table[i]
                if len(slot) != 0:
                    for j in range(len(slot)):
                        print(slot[j][0]+": "+slot[j][1].__str__())
        else:
            for i in range(self.table.size):
                slot = self.table.hash_table[i]
                if slot:
                    print(slot[0]+": "+slot[1].__str__())